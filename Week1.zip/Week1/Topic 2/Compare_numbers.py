a = float(input("Enter first number: "))
b = float(input("Enter second number: "))

if a > b:
    print("First number is greater than second.")
elif a < b:
    print("First number is less than second.")
else:
    print("Both numbers are equal.")
