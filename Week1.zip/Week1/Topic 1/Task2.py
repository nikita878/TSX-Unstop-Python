# This script prints a greeting with the user's name

# Print a greeting message
print("Hello!")

# Print the user's name
print("My name is Nikita.")

# You can also use variables
name = "Nikita"  # Storing name in a variable
print("Nice to meet you, " + name + "!")
